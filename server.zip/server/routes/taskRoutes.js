const express = require('express');
const Task = require('../models/Task');
const router = express.Router();

router.get('/', async (req, res) => {
  const tasks = await Task.find({ $or: [
    { createdBy: req.user.id },
    { assignedTo: req.user.id }
  ] }).populate('assignedTo createdBy', 'name email');
  res.json(tasks);
});

router.post('/', async (req, res) => {
  const { title, description, dueDate, priority, assignedTo } = req.body;
  const task = new Task({
    title,
    description,
    dueDate,
    priority,
    createdBy: req.user.id,
    assignedTo
  });
  await task.save();
  res.status(201).json(task);
});

router.put('/:id', async (req, res) => {
  const task = await Task.findById(req.params.id);
  if (!task) return res.status(404).json({ message: 'Task not found' });
  Object.assign(task, req.body);
  await task.save();
  res.json(task);
});

router.delete('/:id', async (req, res) => {
  const task = await Task.findById(req.params.id);
  if (!task) return res.status(404).json({ message: 'Task not found' });
  await task.deleteOne();
  res.json({ message: 'Task deleted' });
});

module.exports = router;
