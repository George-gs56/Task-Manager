import { useState, useEffect } from 'react';
import styles from './styles/taskForm.module.css';

export default function TaskForm({ onSubmit, onClose, initialData = {} }) {
  const [form, setForm] = useState({
    title: '',
    description: '',
    dueDate: '',
    priority: 'Low',
    status: 'Pending'
  });

  useEffect(() => {
    if (initialData && initialData._id) {
      setForm(initialData);
    }
  }, [initialData]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log("Submitting form:", form);  // Debugging: Log form data
    onSubmit(form);  // Ensure this function correctly handles the form data
  };

  return (
    <div className={styles.modalOverlay}>
      <div className={styles.modal}>
        <h2>{form._id ? 'Edit Task' : 'Create Task'}</h2>
        <form onSubmit={handleSubmit}>
          <input
            name="title"
            placeholder="Title"
            value={form.title}
            onChange={handleChange}
            required
          />
          <textarea
            name="description"
            placeholder="Description"
            value={form.description}
            onChange={handleChange}
          />
          <input
            name="dueDate"
            type="date"
            value={form.dueDate}
            onChange={handleChange}
          />
          <select name="priority" value={form.priority} onChange={handleChange}>
            <option>Low</option>
            <option>Medium</option>
            <option>High</option>
          </select>
          <select name="status" value={form.status} onChange={handleChange}>
            <option>Pending</option>
            <option>In Progress</option>
            <option>Completed</option>
          </select>
          <div className={styles.actions}>
            <button type="submit">{form._id ? 'Update' : 'Create'}</button>
            <button type="button" onClick={onClose}>
              Cancel
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
