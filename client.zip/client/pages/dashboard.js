import { useEffect, useState } from 'react';
import API from '../utils/api';
import TaskForm from './TaskForm';
import styles from './styles/dashboard.module.css';

export default function Dashboard() {
  const [tasks, setTasks] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [editingTask, setEditingTask] = useState(null);

  const fetchTasks = async () => {
    try {
      const res = await API.get('/tasks');
      setTasks(res.data);
    } catch (err) {
      alert('Unauthorized or error fetching tasks');
    }
  };

  const handleCreate = () => {
    setEditingTask(null);
    setShowForm(true);
  };

  const handleEdit = (task) => {
    setEditingTask(task);
    setShowForm(true);
  };

  const handleSubmit = async (formData) => {
    try {
      if (editingTask) {
        await API.put(`/tasks/${editingTask._id}`, formData);
        alert('Task updated');
      } else {
        await API.post('/tasks', formData);
        alert('Task created');
      }
      setShowForm(false);
      fetchTasks();
    } catch (err) {
      alert('Error saving task');
    }
  };

  useEffect(() => {
    fetchTasks();
  }, []);

  return (
    <div className={styles.createTaskBar} >
      <h1>Your Tasks</h1>
      <button onClick={handleCreate} className={styles.createTaskBtn}      >+ Create Task</button>

      {tasks.map((task) => (
        <div key={task._id} className={styles.taskCard}>
          <h3>{task.title}</h3>
          <p>{task.description}</p>
          <p>Status: {task.status}</p>
          <button onClick={() => handleEdit(task)}>Edit</button>
        </div>
      ))}

      {showForm && (
        <TaskForm
          initialData={editingTask}
          onClose={() => setShowForm(false)}
          onSubmit={handleSubmit}
        />
      )}
    </div>
  );
}
