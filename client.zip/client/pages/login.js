import { useState } from 'react';
import styles from './styles/login.module.css';
import API from '../utils/api';
import { useRouter } from 'next/router';

export default function Login() {
  const [form, setForm] = useState({ email: '', password: '' });
  const router = useRouter();

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const res = await API.post('/auth/login', form);
      localStorage.setItem('token', res.data.token);
      router.push('/dashboard');
    } catch (err) {
      alert(err.response?.data?.message || 'Error');
    }
  };

  return (<div className={styles.bk}>
    <form className={styles.form} onSubmit={handleSubmit}>
      <input classname="form input" placeholder="Email" onChange={e => setForm({ ...form, email: e.target.value })} />
      <input classname="form input" placeholder="Password" type="password" onChange={e => setForm({ ...form, password: e.target.value })} />
      <button className='form button' type="submit">Login</button>
    </form>
    </div>
  );
}
