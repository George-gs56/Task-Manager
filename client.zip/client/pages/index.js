import { useEffect, useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/router';
import styles from './styles/index.module.css';

export default function Home() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const router = useRouter();

  useEffect(() => {
    const token = localStorage.getItem('token');
    setIsLoggedIn(!!token);
  }, []);

  const goToDashboard = () => {
    router.push('/dashboard');
  };

  return (
    <div className={styles.container}>
      <h1 className={styles.h1}>Welcome to Task Manager</h1>

      
        <>
          <p className={styles.p}>Please login or register to continue.</p>
          <Link  href="/login"><button className={styles.button}>Login</button></Link>
          <Link  href="/register"><button className={styles.button}>Register</button></Link>
          <Link  href="/dashboard"><button className={styles.button}>Dashboard</button></Link>
        </>
      
    </div>
  );
}
